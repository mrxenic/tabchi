# Tabchi V4.3 By [@MrXeniC](Https://T.Me/MrXeniC)

TG-CLI Based Broadcasting Bot.

## راهنمای نصب :

git clone https://Github.com/mrxenic/tabchi.git

cd tabchi

chmod +x install.sh

./install.sh

## نصب تمام شد

## ران کردن ربات به صورت پیشفرض

cd tabchi

lua creator.lua

بعد ایدی سودو ست کنید مثلا : 353581089

screen ./tabchi-0.sh

شماره ست کنید و حالشو ببرین

## ران کردن بات به صورت دستی

cd tabchi

lua manual-creator.lua

ایدی تبچی ست کنید مثلا : 5

بعدش ایدی سودو بدین مثلا : 353581089

screen ./tabchi-5.sh

شماره ست کنید و حالشو ببرین

# استفاده از انتی کرش

وقتی شماره و همه چی رو ست کردین اول دستور اسکرین استفاده کنید وقتی ربات خاموش شد مراحل زیر رو انجام بدین

cd tabchi

killall bash

./anticrash.sh

عمرا ربات اف بشه :)
