while true; do
$(dirname $0)/telegram-cli-1222 -p tabchi-0 -s tabchi-0.lua
done